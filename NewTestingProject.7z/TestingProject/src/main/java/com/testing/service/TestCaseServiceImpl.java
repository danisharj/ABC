package com.testing.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.testing.dao.TestCaseDao;
import com.testing.dao.TestCaseDaoImpl;
import com.testing.model.TestCase;

public class TestCaseServiceImpl implements TestCaseService {


	@Autowired
	TestCaseDao testCaseDao;
	@Override
	public void addData(TestCase testcase) {
		
		//TestCase tp = new TestCase();
		 
		// tp.setTestCase_id(testCase_id);
		 //tp.setTestCase_title(testCase_title);
		 //tp.setTestCase_desc(testCase_desc);
		// tp.setUsed_TsetScript(used_TsetScript);
		// tp.setData_Set(data_Set);
		
		 testCaseDao.save(testcase);
		
	}

	@Override
	public void delete(int id) {
		
		
		testCaseDao.delete(id);
		
	}


	@Override
	public List<TestCase> showAll() {
		
		
		List<TestCase> testcaselist =testCaseDao.showAllTestCase();
		return testcaselist;
		
	}

	@Override
	public void update(int testCase_id, String testCase_title, String testCase_desc,String used_TsetScript, String data_set) {
		
		testCaseDao.update(testCase_id, testCase_title, testCase_desc, used_TsetScript, data_set);
	
	}

	@Override
	public TestCase getTestCaseById(int id) {
		TestCase testcaseinfo=testCaseDao.geTestCaseById(id);
		return testcaseinfo;
	}
	
	

}
