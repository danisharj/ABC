package com.testing.service;

import java.util.List;

import com.testing.model.TestCase;

public interface TestCaseService {
	
	
	//public void addData(int testCase_id,String testCase_title,String testCase_desc,String used_TsetScript,String data_Set);
	public void addData(TestCase testCase);
	public void delete(int id);
	public List<TestCase> showAll();
	public TestCase getTestCaseById(int id);
	public void update(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript, String data_set);

}
