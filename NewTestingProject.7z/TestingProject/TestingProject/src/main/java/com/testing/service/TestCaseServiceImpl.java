package com.testing.service;

import java.util.List;

import com.testing.dao.TestCaseDaoImpl;
import com.testing.model.TestCase;

public class TestCaseServiceImpl implements TestCaseService {

	@Override
	public void addData(int testCase_id,String testCase_title,String testCase_desc,String used_TsetScript,String data_Set) {
		
		
		 TestCase tp = new TestCase();
		 tp.setTestCase_id(testCase_id);
		 tp.setTestCase_title(testCase_title);
		 tp.setTestCase_desc(testCase_desc);
		 tp.setUsed_TsetScript(used_TsetScript);
		 tp.setData_Set(data_Set);
		 TestCaseDaoImpl tcdi=new TestCaseDaoImpl();
		 tcdi.save(tp);
		
	}

	@Override
	public void delete() {
		
		
	}

	@Override
	public void update() {
		
		
	}

	@Override
	public List<TestCase> showAll() {
		
		TestCaseDaoImpl tcdi=new TestCaseDaoImpl();
		List<TestCase> testcaselist =tcdi.showAllTestCase();
		return testcaselist;
		
	}
	
	

}
