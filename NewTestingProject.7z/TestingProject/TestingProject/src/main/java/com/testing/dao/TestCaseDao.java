package com.testing.dao;

import java.util.List;

import com.testing.model.TestCase;

public interface TestCaseDao {
	
	
	public void save(TestCase t);
	public List<TestCase> showAllTestCase();

}
