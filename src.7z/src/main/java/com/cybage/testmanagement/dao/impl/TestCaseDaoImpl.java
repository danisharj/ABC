package com.cybage.testmanagement.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.cybage.testmanagement.config.HibernateSessionManager;
import com.cybage.testmanagement.dao.TestCaseDao;
import com.cybage.testmanagement.model.TestCaseModel;

@Repository
public class TestCaseDaoImpl implements TestCaseDao {

	public void save(TestCaseModel t) {
		
		Session session = HibernateSessionManager.getSessionFactory().openSession();
		 
		 session.beginTransaction();
		 session.save(t);
		 session.getTransaction().commit();

	}

	public List<TestCaseModel> showAllTestCase() {
		
		Session session = HibernateSessionManager.getSessionFactory().openSession();
		 session.beginTransaction();
		 List<TestCaseModel> testcaselist = session.createCriteria(TestCaseModel.class).list();

		 
		 return testcaselist;
	}

	public void delete(int id) {
		Session session = HibernateSessionManager.getSessionFactory().openSession();
		
		 Transaction tx = session.beginTransaction();  
		    Object obj3 = session.load(TestCaseModel.class, new Integer(id));     
		    TestCaseModel s4 = (TestCaseModel) obj3;
		 
		    session.delete(s4);
		    tx.commit();   
	}

	public void update(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript,
			String data_set) {
		Session session = HibernateSessionManager.getSessionFactory().openSession();
		
		 Transaction tx = session.beginTransaction();  
		    Object obj3 = session.load(TestCaseModel.class, new Integer(testCase_id));     
		    TestCaseModel s4 = (TestCaseModel) obj3;
		  s4.setTestCase_id(testCase_id);
		  s4.setTestCase_title(testCase_title);
		  s4.setTestCase_desc(testCase_desc);
		  s4.setUsed_TsetScript(used_TsetScript);
		  s4.setData_Set(data_set);
		   tx.commit();
	}

	public TestCaseModel geTestCaseById(int id) {
		Session session = HibernateSessionManager.getSessionFactory().openSession();
		
		 Transaction tx = session.beginTransaction();  
		    Object obj3 = session.load(TestCaseModel.class, new Integer(id));     
		    TestCaseModel s4 = (TestCaseModel) obj3;
		    System.out.println(s4);
		   tx.commit();
		
		return s4;
	}


}
