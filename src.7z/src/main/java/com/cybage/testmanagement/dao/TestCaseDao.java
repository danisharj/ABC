package com.cybage.testmanagement.dao;

import java.util.List;

import com.cybage.testmanagement.model.TestCaseModel;

public interface TestCaseDao {


	
	public void save(TestCaseModel t);
	public List<TestCaseModel> showAllTestCase();
	public void delete(int id);
	void update(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript, String data_set);
    public TestCaseModel geTestCaseById(int id);

}
