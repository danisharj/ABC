package com.cybage.testmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.testmanagement.dao.TestCaseDao;
import com.cybage.testmanagement.model.TestCaseModel;
import com.cybage.testmanagement.service.TestCaseService;

@Service
public class TestCaseServiceImpl implements TestCaseService {


	@Autowired
	TestCaseDao testCaseDao;

	public void addData(TestCaseModel testCase) {
		
		 testCaseDao.save(testCase);
	}

	public void delete(int id) {
		
		testCaseDao.delete(id);
		
	}

	public List<TestCaseModel> showAll() {
		
		List<TestCaseModel> testcaselist =testCaseDao.showAllTestCase();
		return testcaselist;
	}

	public TestCaseModel getTestCaseById(int id) {
		TestCaseModel testcaseinfo=testCaseDao.geTestCaseById(id);
		return testcaseinfo;
	}

	public void update(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript,
			String data_set) {
		testCaseDao.update(testCase_id, testCase_title, testCase_desc, used_TsetScript, data_set);
		
	}

	
}
