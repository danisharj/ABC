package com.cybage.testmanagement.service;

import com.cybage.testmanagement.model.TestCaseModel;



import java.util.List;



public interface TestCaseService {
	
	
	
	public void addData(TestCaseModel testCase);
	public void delete(int id);
	public List<TestCaseModel> showAll();
	public TestCaseModel getTestCaseById(int id);
	public void update(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript, String data_set);

}
