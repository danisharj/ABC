package com.cybage.testmanagement.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.testmanagement.dto.TestCaseDTO;
import com.cybage.testmanagement.model.TestCaseModel;
import com.cybage.testmanagement.service.TestCaseService;


@RestController
@RequestMapping("/testCase")
public class TestCaseController {

	@Autowired
	TestCaseService testCaseService;

	@RequestMapping(value = "/getTestCase/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public TestCaseDTO getTestCases(@PathVariable int id) {
		TestCaseModel testCaseModel = testCaseService.getTestCaseById(id);
		ModelMapper modelMapper = new ModelMapper();
		TestCaseDTO testCaseDTO = modelMapper.map(testCaseModel,TestCaseDTO.class);
		return testCaseDTO;
	}
	
	@RequestMapping(value = "/addTestCase", method = RequestMethod.POST, headers = "Accept=application/json")
	public void getTestCases(@RequestBody TestCaseDTO testCaseDto) {
		System.out.println("Test Case Id"+testCaseDto.getTestCase_id());
		ModelMapper modelMapper = new ModelMapper();
		TestCaseModel testCaseModel = modelMapper.map(testCaseDto,TestCaseModel.class);
		testCaseService.addData(testCaseModel);
	}
	
	@RequestMapping(value = "/deleteTestCase/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public void getTestCase(@PathVariable int id) {
		 testCaseService.delete(id);
		System.out.println("Test Case Id "+id+" Deleted");
		
	}
	
	
	@RequestMapping(value = "/viewAllTestCases", method = RequestMethod.GET)
	public ResponseEntity<List<TestCaseModel>> listAllUsers() {
		List<TestCaseModel> testScriptModelList = testCaseService.showAll();
		if (testScriptModelList.isEmpty()) {
			return new ResponseEntity<List<TestCaseModel>>(HttpStatus.NO_CONTENT);

		}
		return new ResponseEntity<List<TestCaseModel>>(testScriptModelList, HttpStatus.OK);
	}
	
	@RequestMapping(value="edit/update")
	public void test4(HttpServletResponse response,HttpServletRequest request,ModelMap model) throws IOException{
		int testCase_id=Integer.parseInt(request.getParameter("id"));
		String testCase_title=request.getParameter("title");
		String testCase_desc=request.getParameter("desc");	
		String used_TsetScript=request.getParameter("test_script");
		System.out.println(used_TsetScript);
		String data_set=request.getParameter("data_set");
		
		
		testCaseService.update(testCase_id, testCase_title, testCase_desc, used_TsetScript, data_set);
		
	
	}
}
