package com.cybage.testmanagement.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.context.annotation.Lazy;

@Entity
@Table(name = "TestScript")
@Lazy(value = false)
public class TestScriptModel implements Serializable {

	private int testScriptId;
	private String testScriptTitle;
	private String testScriptDescription;
	private String testScriptExecutionInstruction;
	private String testScriptDataset;

	@Id
	@GeneratedValue
	@Column(name = "testScriptId", unique = true, nullable = false)
	public int getTestScriptId() {
		return testScriptId;
	}

	public void setTestScriptId(int testScriptId) {
		this.testScriptId = testScriptId;
	}

	@Column(name = "testScriptTitle")
	public String getTestScriptTitle() {
		return testScriptTitle;
	}

	public void setTestScriptTitle(String testScriptTitle) {
		this.testScriptTitle = testScriptTitle;
	}

	@Column(name = "testScriptDescription")
	public String getTestScriptDescription() {
		return testScriptDescription;
	}

	public void setTestScriptDescription(String testScriptDescription) {
		this.testScriptDescription = testScriptDescription;
	}

	@Column(name = "testScriptExecutionInstruction")
	public String getTestScriptExecutionInstruction() {
		return testScriptExecutionInstruction;
	}

	public void setTestScriptExecutionInstruction(String testScriptExecutionInstruction) {
		this.testScriptExecutionInstruction = testScriptExecutionInstruction;
	}

	@Column(name = "testScriptDataset")
	public String getTestScriptDataset() {
		return testScriptDataset;
	}

	public void setTestScriptDataset(String testScriptDataset) {
		this.testScriptDataset = testScriptDataset;
	}
	
	

}
