package com.cybage.testmanagement.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.JoinColumn;


@Entity
@Table(name = "Test_Case")

public class TestCaseModel {
	
	
	@Id @GeneratedValue
	@Column(name = "TestCase_id")
	private int testCase_id;
	
	@Column(name = "TestCase_title")
	private String testCase_title;
	
	@Column(name = "TestCase_desc")
	private String testCase_desc;
	
	@Column(name = "Used_TsetScript")
	private String used_TsetScript;
	
	@Column(name = "Data_Set")
	private String data_Set;
/*
	public Set<TestScriptModel> testScriptId=new HashSet<TestScriptModel>();
	//====================================================================================
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "TestCase_TestScript", joinColumns = { @JoinColumn(name = "TestCase_id") }, inverseJoinColumns = { @JoinColumn(name = "testScriptId") })
	public Set<TestScriptModel> getTestScriptTitle() {
		return this.testScriptId;
	}
	public void  setTestScriptTitle(Set<TestScriptModel> testScriptId) {
		this.testScriptId=testScriptId;
	}
*/
//================================================================================================
	public int getTestCase_id() {
		return testCase_id;
	}

	public void setTestCase_id(int testCase_id) {
		this.testCase_id = testCase_id;
	}

	public String getTestCase_title() {
		return testCase_title;
	}

	public void setTestCase_title(String testCase_title) {
		this.testCase_title = testCase_title;
	}

	public String getTestCase_desc() {
		return testCase_desc;
	}

	public void setTestCase_desc(String testCase_desc) {
		this.testCase_desc = testCase_desc;
	}

	public String getUsed_TsetScript() {
		return used_TsetScript;
	}

	public void setUsed_TsetScript(String used_TsetScript) {
		this.used_TsetScript = used_TsetScript;
	}

	public String getData_Set() {
		return data_Set;
	}

	public void setData_Set(String data_Set) {
		this.data_Set = data_Set;
	}

	@Override
	public String toString() {
		return "TestCaseModel [testCase_id=" + testCase_id + ", testCase_title=" + testCase_title + ", testCase_desc="
				+ testCase_desc + ", used_TsetScript=" + used_TsetScript + ", data_Set=" + data_Set + "]";
	}
	
	
	
}
