package com.cybage.testmanagement.dto;

import javax.persistence.Column;

import org.springframework.beans.factory.annotation.Autowired;

import com.cybage.testmanagement.model.TestCaseModel;

public class TestCaseDTO {

	private int testCase_id;
	
	
	private String testCase_title;
	
	
	private String testCase_desc;
	
	
	private String used_TsetScript;
	
	
	public int getTestCase_id() {
		return testCase_id;
	}


	public void setTestCase_id(int testCase_id) {
		this.testCase_id = testCase_id;
	}


	public String getTestCase_title() {
		return testCase_title;
	}


	public void setTestCase_title(String testCase_title) {
		this.testCase_title = testCase_title;
	}


	public String getTestCase_desc() {
		return testCase_desc;
	}


	public void setTestCase_desc(String testCase_desc) {
		this.testCase_desc = testCase_desc;
	}


	public String getUsed_TsetScript() {
		return used_TsetScript;
	}


	public void setUsed_TsetScript(String used_TsetScript) {
		this.used_TsetScript = used_TsetScript;
	}


	public String getData_Set() {
		return data_Set;
	}


	public void setData_Set(String data_Set) {
		this.data_Set = data_Set;
	}


	private String data_Set;
}
