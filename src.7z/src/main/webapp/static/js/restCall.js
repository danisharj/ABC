 

angular.module('demo', [])
      .controller('Hello', function($scope, $http) {
          $http.get('http://localhost:8080/TestCaseManagement/testCase/getTestCase/2').
              then(function(response) {
                  $scope.greeting = response.data;
              });
      });