package com.testingproject.TestingProject.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.testing.model.TestCase;
import com.testing.service.TestCaseServiceImpl;

@Controller
public class HomeController {

	@RequestMapping(value="/testcase")
	public ModelAndView test(HttpServletResponse response) throws IOException{
		return new ModelAndView("home");
	}
	
	
	
	@RequestMapping(value="/createtestcase")
	public ModelAndView test2(HttpServletResponse response,ModelMap model) throws IOException{
		TestCaseServiceImpl tcsi=new TestCaseServiceImpl();
		List<TestCase> testcaselist=tcsi.showAll();
		//System.out.println(testcaselist);
		model.addAttribute("testcaselist",testcaselist);
		return new ModelAndView("createtestcase");
	}
	
	
	@RequestMapping(value="/save")
	public ModelAndView test3(HttpServletResponse response,HttpServletRequest request,ModelMap model) throws IOException{
		int testCase_id=Integer.parseInt(request.getParameter("id"));
		String testCase_title=request.getParameter("title");
		String testCase_desc=request.getParameter("desc");	
		String used_TsetScript=request.getParameter("test_script");
		//System.out.println(used_TsetScript);
		String data_set=request.getParameter("data_set");
		
		TestCaseServiceImpl tcsi=new TestCaseServiceImpl();
		tcsi.addData(testCase_id, testCase_title, testCase_desc, used_TsetScript, data_set);
		
		List<TestCase> testcaselist=tcsi.showAll();
		//System.out.println(testcaselist);
		model.addAttribute("testcaselist",testcaselist);
		
		return new ModelAndView("createtestcase");
	}
	
	@RequestMapping(value="/showalltestcase")
	public ModelAndView test3(HttpServletResponse response,ModelMap model) throws IOException{
		TestCaseServiceImpl tcsi=new TestCaseServiceImpl();
		List<TestCase> testcaselist=tcsi.showAll();
		model.addAttribute("testcaselist",testcaselist);
		return new ModelAndView("alltestcases");
	}
	
	@RequestMapping(value="/delete/{id}")
	public String removeTestCase(@PathVariable("id") int id){
		//System.out.println(id);
		 TestCaseServiceImpl testCaseServiceImpl=new TestCaseServiceImpl();
		 testCaseServiceImpl.delete(id);
		return "redirect:/createtestcase";
	}
	
	
	@RequestMapping(value="/edit/{id}")
	public ModelAndView editTestCase(@PathVariable("id") int id,ModelMap model){
		
		TestCaseServiceImpl tcsi=new TestCaseServiceImpl();
		List<TestCase> testcaselist=tcsi.showAll();
		//System.out.println(testcaselist);
		TestCase testcaseinfo=tcsi.getTestCaseById(id);
		model.addAttribute("testcaselist",testcaselist);
		model.addAttribute("testcaseinfo", testcaseinfo);
		return new ModelAndView("edittestcaselist");
		
		
		
	}
	
	@RequestMapping(value="edit/update")
	public String test4(HttpServletResponse response,HttpServletRequest request,ModelMap model) throws IOException{
		int testCase_id=Integer.parseInt(request.getParameter("id"));
		String testCase_title=request.getParameter("title");
		String testCase_desc=request.getParameter("desc");	
		String used_TsetScript=request.getParameter("test_script");
		System.out.println(used_TsetScript);
		String data_set=request.getParameter("data_set");
		
		TestCaseServiceImpl tcsi=new TestCaseServiceImpl();
		tcsi.update(testCase_id, testCase_title, testCase_desc, used_TsetScript, data_set);
		
		List<TestCase> testcaselist=tcsi.showAll();
		//System.out.println(testcaselist);
		model.addAttribute("testcaselist",testcaselist);
		
		//return new ModelAndView("createtestcase");
		return "redirect:/createtestcase";
	}
	
	
	@RequestMapping(value="/testcase/{id}", method = RequestMethod.GET, headers = "Accept=application/json", produces={"application/json"})
	public ResponseEntity getTestCase(@PathVariable("id") int id) {
		TestCaseServiceImpl tcsi=new TestCaseServiceImpl();
		TestCase testcaseinfo=tcsi.getTestCaseById(id);
		if (testcaseinfo == null) {
			return new ResponseEntity("No Customer found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(testcaseinfo, HttpStatus.OK);
	}
	
	
}
