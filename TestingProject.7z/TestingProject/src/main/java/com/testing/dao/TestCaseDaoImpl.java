package com.testing.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import com.testing.model.TestCase;
import com.testingproject.TestingProject.config.HibernateSessionManager;

public class TestCaseDaoImpl implements TestCaseDao {
	
	@Override
	public void save(TestCase t) {
		
		Session session = HibernateSessionManager.getSessionFactory().openSession();
		 
		 session.beginTransaction();
		 session.save(t);
		 session.getTransaction().commit();
		
	}
	@Override
	public List<TestCase> showAllTestCase() {
		Session session = HibernateSessionManager.getSessionFactory().openSession();
		 session.beginTransaction();
		 List<TestCase> testcaselist = session.createCriteria(TestCase.class).list();

		 
		 return testcaselist;
		
	}
	@Override
	public void delete(int id) {
		Session session = HibernateSessionManager.getSessionFactory().openSession();
		
		 Transaction tx = session.beginTransaction();  
		    Object obj3 = session.load(TestCase.class, new Integer(id));     
		    TestCase s4 = (TestCase) obj3;
		 
		    session.delete(s4);
		    tx.commit();                          
		
	}
	@Override
	public  void update(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript, String data_set){
		Session session = HibernateSessionManager.getSessionFactory().openSession();
		
		 Transaction tx = session.beginTransaction();  
		    Object obj3 = session.load(TestCase.class, new Integer(testCase_id));     
		    TestCase s4 = (TestCase) obj3;
		  s4.setTestCase_id(testCase_id);
		  s4.setTestCase_title(testCase_title);
		  s4.setTestCase_desc(testCase_desc);
		  s4.setUsed_TsetScript(used_TsetScript);
		  s4.setData_Set(data_set);
		   tx.commit();
		   
		
	}
	@Override
	public TestCase geTestCaseById(int id) {
		Session session = HibernateSessionManager.getSessionFactory().openSession();
		
		 Transaction tx = session.beginTransaction();  
		    Object obj3 = session.load(TestCase.class, new Integer(id));     
		    TestCase s4 = (TestCase) obj3;
		   tx.commit();
		
		return s4;
	}

}
