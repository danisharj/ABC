package com.testing.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.testing.dao.TestCaseDaoImpl;
import com.testing.model.TestCase;

public class TestCaseServiceImpl implements TestCaseService {


	@Autowired
	TestCaseDaoImpl testCaseDaoImpl=new TestCaseDaoImpl();
	@Override
	public void addData(int testCase_id,String testCase_title,String testCase_desc,String used_TsetScript,String data_Set) {
		
		TestCase tp = new TestCase();
		 
		 tp.setTestCase_id(testCase_id);
		 tp.setTestCase_title(testCase_title);
		 tp.setTestCase_desc(testCase_desc);
		 tp.setUsed_TsetScript(used_TsetScript);
		 tp.setData_Set(data_Set);
		
		 testCaseDaoImpl.save(tp);
		
	}

	@Override
	public void delete(int id) {
		
		
		testCaseDaoImpl.delete(id);
		
	}


	@Override
	public List<TestCase> showAll() {
		
		
		List<TestCase> testcaselist =testCaseDaoImpl.showAllTestCase();
		return testcaselist;
		
	}

	@Override
	public void update(int testCase_id, String testCase_title, String testCase_desc,String used_TsetScript, String data_set) {
		
		testCaseDaoImpl.update(testCase_id, testCase_title, testCase_desc, used_TsetScript, data_set);
	
	}

	@Override
	public TestCase getTestCaseById(int id) {
		TestCase testcaseinfo=testCaseDaoImpl.geTestCaseById(id);
		return testcaseinfo;
	}
	
	

}
