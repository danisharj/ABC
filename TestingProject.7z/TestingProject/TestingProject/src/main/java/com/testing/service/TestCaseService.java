package com.testing.service;

import java.util.List;

import com.testing.model.TestCase;

public interface TestCaseService {
	
	
	public void addData(int testCase_id,String testCase_title,String testCase_desc,String used_TsetScript,String data_Set);
	public void delete();
	public void update();
	public List<TestCase> showAll();

}
