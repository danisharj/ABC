package com.testing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Test_Case")

public class TestCase {
	
	
	@Id @GeneratedValue
	@Column(name = "TestCase_id")

	private int testCase_id;
	
	@Column(name = "TestCase_title")
	private String testCase_title;
	
	@Column(name = "TestCase_desc")
	private String testCase_desc;
	
	@Column(name = "Used_TsetScript")
	private String used_TsetScript;
	
	@Column(name = "Data_Set")
	private String data_Set;

	public int getTestCase_id() {
		return testCase_id;
	}

	public void setTestCase_id(int testCase_id) {
		this.testCase_id = testCase_id;
	}

	public String getTestCase_title() {
		return testCase_title;
	}

	public void setTestCase_title(String testCase_title) {
		this.testCase_title = testCase_title;
	}

	public String getTestCase_desc() {
		return testCase_desc;
	}

	public void setTestCase_desc(String testCase_desc) {
		this.testCase_desc = testCase_desc;
	}

	public String getUsed_TsetScript() {
		return used_TsetScript;
	}

	public void setUsed_TsetScript(String used_TsetScript) {
		this.used_TsetScript = used_TsetScript;
	}

	public String getData_Set() {
		return data_Set;
	}

	public void setData_Set(String data_Set) {
		this.data_Set = data_Set;
	}

	@Override
	public String toString() {
		return "TestCase [testCase_id=" + testCase_id + ", testCase_title=" + testCase_title + ", testCase_desc="
				+ testCase_desc + ", used_TsetScript=" + used_TsetScript + ", data_Set=" + data_Set + "]";
	}

	
	
	

}
