package com.testing.dao;

import java.util.List;

import org.hibernate.Session;

import com.testing.model.TestCase;
import com.testingproject.TestingProject.config.HibernateSessionManager;

public class TestCaseDaoImpl implements TestCaseDao {
	Session session = HibernateSessionManager.getSessionFactory().openSession();
	@Override
	public void save(TestCase t) {
		
		
		 
		 session.beginTransaction();
		 session.save(t);
		 session.getTransaction().commit();
		
	}
	@Override
	public List<TestCase> showAllTestCase() {
		
		 session.beginTransaction();
		 List<TestCase> testcaselist = session.createCriteria(TestCase.class).list();

		 
		 return testcaselist;
		
	}

}
