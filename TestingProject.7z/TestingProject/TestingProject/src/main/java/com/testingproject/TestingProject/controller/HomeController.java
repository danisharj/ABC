package com.testingproject.TestingProject.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.testing.model.TestCase;
import com.testing.service.TestCaseServiceImpl;

@Controller
public class HomeController {

	@RequestMapping(value="/testcase")
	public ModelAndView test(HttpServletResponse response) throws IOException{
		return new ModelAndView("home");
	}
	
	
	
	@RequestMapping(value="/createtestcase")
	public ModelAndView test2(HttpServletResponse response) throws IOException{
		return new ModelAndView("createtestcase");
	}
	
	
	@RequestMapping(value="/save")
	public ModelAndView test3(HttpServletResponse response,HttpServletRequest request,ModelMap model) throws IOException{
		int testCase_id=Integer.parseInt(request.getParameter("id"));
		String testCase_title=request.getParameter("title");
		String testCase_desc=request.getParameter("desc");	
		String used_TsetScript=request.getParameter("test_script");
		System.out.println(used_TsetScript);
		String data_set=request.getParameter("data_set");
		
		TestCaseServiceImpl tcsi=new TestCaseServiceImpl();
		tcsi.addData(testCase_id, testCase_title, testCase_desc, used_TsetScript, data_set);
		
		return new ModelAndView("home");
	}
	
	@RequestMapping(value="/showalltestcase")
	public ModelAndView test3(HttpServletResponse response,ModelMap model) throws IOException{
		TestCaseServiceImpl tcsi=new TestCaseServiceImpl();
		List<TestCase> testcaselist=tcsi.showAll();
		model.addAttribute("testcaselist",testcaselist);
		return new ModelAndView("alltestcases");
	}
	
}
