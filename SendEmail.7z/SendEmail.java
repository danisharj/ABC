package com.cybage.mail;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendEmail {
	
	public static void main(String args[]) throws AddressException, MessagingException
	{
		String to="rajatk@cybage.com";
		String from="danishe@cybage.com";
		String host="172.27.209.162";
		System.out.println("hi0");
		Properties properties=System.getProperties();
		
		properties.setProperty("mail.smtp.host", host);
		System.out.println("hi1");
		properties.put("mail.smtp.host", "mail.cybage.com");
		System.out.println("hi2");
		
		final String login = "danishe@cybage.com";
		final String pass = "Wamique@2017";
		properties.setProperty("mail.smtp.user", login);
		properties.setProperty("mail.smtp.password", pass);
		properties.setProperty("mail.smtp.auth", "true");      

		
		
		
		
		
		properties.put("mail.smtp.port", "587");
		System.out.println("hi3");
		properties.put("mail.smtp.starttls.enable", "true");
		//properties.put("mail.smtp.auth", "true");
		System.out.println("hi4");
		 Session session = Session.getDefaultInstance(properties);  
		 
		
		 Session session2 = Session.getInstance(properties, new javax.mail.Authenticator() {
			    protected PasswordAuthentication getPasswordAuthentication() {
			    	
			    	System.out.println(pass);
			        return new PasswordAuthentication(login, pass);
			    }
			});
		
		 
		 
		 MimeMessage message=new MimeMessage(session2);
		 System.out.println("hi5");
		 message.setFrom(new InternetAddress(from));
		 System.out.println("hi6");
		 message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
		 System.out.println("hi7");
		 message.setSubject("Testing mail api");
		 message.setText("Hi Rajat,This is example of sending email,yooo");
		 System.out.println("hi8");
		 Transport transport = session.getTransport("smtp");
			transport.connect(null, login, pass);
		 Transport.send(message);
		 System.out.println("hi9");
		 System.out.println("message send successfully");
		 
	}

}
